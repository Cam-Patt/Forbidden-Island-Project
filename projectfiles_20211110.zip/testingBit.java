import java.io.IOException;

public class testingBit {

	public static void main(String[] args) throws IOException {
		boardObject o = new boardObject();

	}

}
