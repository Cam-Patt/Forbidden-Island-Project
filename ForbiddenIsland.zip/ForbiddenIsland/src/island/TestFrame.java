package island;

import javax.swing.JFrame;

public class TestFrame extends JFrame{
	public static final int WIDTH = 1600;
	public static final int HEIGHT = 480;
	public TestFrame(String title) {
		super(title);
		TitlePanel j = new TitlePanel();
		this.add(j);
		setSize(WIDTH,HEIGHT);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
		
	}
}
