package island;

import java.io.IOException;

public class TitleRunner {
	public static void main(String args[]) throws IOException {	
		TestFrame panel = new TestFrame("Forbidden Island");
	}
}

