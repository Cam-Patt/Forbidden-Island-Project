package island;

import java.awt.GridLayout;
import javax.swing.JPanel;

public class TitlePanel extends JPanel{
	public TitlePanel() {
		this.setLayout(new GridLayout(2, 0));
		TitleImagePanel i = new TitleImagePanel();
		TitleButtonPanel b = new TitleButtonPanel();
		this.add(i);
		this.add(b);
	}
}
