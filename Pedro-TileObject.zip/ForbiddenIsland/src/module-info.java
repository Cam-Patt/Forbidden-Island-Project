module ForbiddenIsland {
	requires java.desktop;
}