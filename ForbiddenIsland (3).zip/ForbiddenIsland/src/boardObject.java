import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;
import java.util.Random;
import java.io.File;
import java.nio.file.Files;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
public class boardObject {
	private TileObject[][] boardMatrix;
	private ArrayList<TileObject> tiles;
	public boardObject() throws IOException {
		boardMatrix = new TileObject[6][6];
		tiles = new ArrayList<TileObject>();	
		/* Making all the tiles*/
		//tiles.add( new TileObject("Breakers Bridge","none","Breakers Bridge@2x.png", "Breakers Bridge_flood@2x.png"));
		// This needs to be a resource

		File f =new File("/textfiles/" + "tileList.txt"); //has the name of each tile
		Scanner tileTitle = new Scanner(f);
		while(tileTitle.hasNext()) {
			String title = tileTitle.nextLine();
			TileObject t = new TileObject(title, "none", title + "@2x.png", title + "_flood@2x.png");
			tiles.add(t);
		}
		/* w = water
		 * t = tiles
		 * 
		 *   0 1 2 3 4 5
		 *0  w w t t w w
		 *1  w t t t t w
		 *2  t t t t t t
		 *3  t t t t t t
		 *4  w t t t t w
		 *5  w w t t w w*/
//		shuffle(12346);
		shuffle();
	}
	public void shuffle(int sed) throws IOException {
		ArrayList<TileObject> temp = new ArrayList<TileObject>();
		Random r = new Random(sed);
		while(tiles.size() > 0) {
			int index = r.nextInt(tiles.size());
			temp.add(tiles.get(index));
			tiles.remove(index);
	
		}
		tiles = temp;
		fill(tiles);
	}
	public void shuffle() throws IOException {
		ArrayList<TileObject> temp = new ArrayList<TileObject>();
		Random r = new Random();
		while(tiles.size() > 0) {
			int index = r.nextInt(tiles.size());
			temp.add(tiles.get(index));
			tiles.remove(index);
	
		}
		tiles = temp;
		fill(tiles);
	}
	public void fill(ArrayList<TileObject>t) throws IOException {
		Iterator<TileObject> iter = t.iterator();
		/*
		    0 1 2 3 4 5
		 *0  w w t t w w
		 *1  w w t t w w
		 *2  w w t t w w
		 *3  w w t t w w
		 *4  w w t t w w
		 *5  w w t t w w*/
		for(int i = 0; i < boardMatrix.length; i++) {
			boardMatrix[i][2] = iter.next();
			boardMatrix[i][3] = iter.next();
		}
		
		/*
	    0 1 2 3 4 5
	 *0  w w t t w w
	 *1  w w t t w w
	 *2  t t t t w w
	 *3  t t t t w w
	 *4  w w t t w w
	 *5  w w t t w w*/
		boardMatrix[2][0] = iter.next();
		boardMatrix[2][1] = iter.next();
		boardMatrix[3][0] = iter.next();
		boardMatrix[3][1] = iter.next();
		
		/*
	    0 1 2 3 4 5
	 *0  w w t t w w
	 *1  w w t t w w
	 *2  t t t t t t
	 *3  t t t t t t
	 *4  w w t t w w
	 *5  w w t t w w*/
		boardMatrix[2][4] = iter.next();
		boardMatrix[2][5] = iter.next();
		boardMatrix[3][4] = iter.next();
		boardMatrix[3][5] = iter.next();
		
		/*
	    0 1 2 3 4 5
	 *0  w w t t w w
	 *1  w t t t t w
	 *2  t t t t t t
	 *3  t t t t t t
	 *4  w t t t t w
	 *5  w w t t w w*/
		boardMatrix[1][1] = iter.next();
		boardMatrix[1][4] = iter.next();
		boardMatrix[4][1] = iter.next();
		boardMatrix[4][4] = iter.next();
		
		//filling the rest with water
		for(int r = 0; r < boardMatrix.length; r++) {
			for(int c = 0; c < boardMatrix[r].length; c++) {
				if(boardMatrix[r][c] == null) {
					boardMatrix[r][c] = new TileObject("water","none","Tile_Flood_Water@2x.png", "Tile_Flood_Water@2x.png");
					boardMatrix[r][c].setCanTravel(false);
				}
			}
		}
	}
	public TileObject[][] getBoard() {
		return boardMatrix;
	}
	public String toString() {
		String str = "";
		for(int l = 0; l < boardMatrix.length; l++) {
			for(int g = 0; g < boardMatrix[l].length; g++) {
			str+=("|"+boardMatrix[l][g].getName() + "|");
			}
			str += "\n";
		}
		return str;
	}
}
