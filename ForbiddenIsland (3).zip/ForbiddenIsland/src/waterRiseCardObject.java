import java.awt.image.*;
public class waterRiseCardObject extends treasureCardObject{
	public waterRiseCardObject(BufferedImage i, String s) {
		super(i,s);
	}
	public String toString() {
		return "water Rise!";
	}
}
