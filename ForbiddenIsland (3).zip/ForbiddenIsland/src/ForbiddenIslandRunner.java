import java.io.IOException;

public class ForbiddenIslandRunner {
	public static void main(String[] args) throws IOException {
		ForbiddenIslandFrame f = new ForbiddenIslandFrame("This is professsional");
	}
}
