import java.awt.*;
import java.io.IOException;

import javax.swing.*;
public class testingFrame extends JFrame{
	private static final int WIDTH = 1600;
	private static final int HEIGHT = 960;
	public testingFrame(String str) throws IOException {
		super(str);
		setSize(WIDTH,HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		instructionPanel i = new instructionPanel();
		add(i);
	}
}
