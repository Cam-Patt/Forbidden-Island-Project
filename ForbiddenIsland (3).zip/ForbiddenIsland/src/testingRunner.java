import java.io.IOException;

public class testingRunner {
	public static void main(String[] args) throws IOException {
		testingFrame f = new testingFrame("mmmmmmmmm");
	}
}
