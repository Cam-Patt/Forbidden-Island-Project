import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.*;
public class instructionPanel extends JPanel{
	public instructionPanel()throws IOException {
		File file = new File("forbiddenIslandInstructions.txt");
		FileWriter f = new FileWriter(file);
		Scanner c = new Scanner(new File("readfrom.txt"));
		while(c.hasNextLine()) {
			f.write(c.nextLine());
		}
		f.close();
		repaint();
	}
	public void paint(Graphics g) {
		g.setColor(Color.BLUE);
		g.drawLine(0,0,getWidth(), getHeight());
		g.drawString("To get the instructions",getWidth()/2 - getWidth()/4, getHeight()/2 - getHeight()/4);
		g.drawString("Go to file explorer",getWidth()/2 - getWidth()/4, getHeight()/2 - getHeight()/3);
		g.drawString("Look for forbiddenIslandInstructions.txt",getWidth()/2 - getWidth()/4,(int)( getHeight()/2 - getHeight()/3.4));
	}
}
