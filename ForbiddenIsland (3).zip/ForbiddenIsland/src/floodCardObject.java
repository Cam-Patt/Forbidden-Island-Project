import java.awt.image.*;
public class floodCardObject extends cardObject{
	public floodCardObject(BufferedImage i, String s) {
		super(i, s);
	}
	
}
