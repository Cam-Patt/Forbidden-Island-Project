package island;

import java.io.IOException;

public class TitleRunner {
	public static void main(String args[]) throws IOException {	
		TitlePanel panel = new TitlePanel("Forbidden Island");
	}
}
